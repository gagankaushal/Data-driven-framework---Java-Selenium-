package Utilies;

public class StoreValuefromExcel {

	// step number
	public String id;
	public String keyword;
	public String identified_by;
	//Target identify_by in case of dropdown
	public String target_identify_by="N";
	public String Data;
	public String Executionindicator;
	public String waitTime;
	
	public StoreValuefromExcel (String keyword,String identified_by,String target_identify_by,String Data,String Executionindicator, String waitTime)
	{
		
		this.Data=Data;
		this.keyword=keyword;
		this.identified_by=identified_by;
		this.target_identify_by=target_identify_by;
		this.Executionindicator=Executionindicator;
		this.waitTime=waitTime;
		
	}
}
